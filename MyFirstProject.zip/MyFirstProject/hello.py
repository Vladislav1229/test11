print("Hello World!")
print("Я научился запускать Python через venv!")
print("Это моя первая программа!")